package com.br.books2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Books2Application {

	public static void main(String[] args) {
		SpringApplication.run(Books2Application.class, args);
	}

}

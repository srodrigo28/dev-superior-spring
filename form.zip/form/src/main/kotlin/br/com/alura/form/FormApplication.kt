package br.com.alura.form

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class FormApplication

fun main(args: Array<String>) {
	runApplication<FormApplication>(*args)
}
